<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Product;

 

class PrintController extends Controller

{

       public function index()

      {

              $schedules = Product::all();

              return view('print/printschedule')->with('schedules', $schedules);;

     }

    

     public function prnpriview()

     {

              $schedules = Product::all();

              return view('print/schedule')->with('schedules', $schedules);;

     }

}
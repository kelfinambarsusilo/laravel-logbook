<html>

<head>

<link rel="stylesheet" href="css/bootstrap.css">

<script type="text/javascript" src="js/bootstrap.min.js"></script>

<script type="text/javascript" src="js/jquery-2.2.4.min.js"></script>

<script type="text/javascript" src="js/jquery.printPage.js"></script>

</head>

<body>

     <div class="container">

      <div class="col-md-12">

               @yield('content')

      </div>

     </div>

</body>

</html>
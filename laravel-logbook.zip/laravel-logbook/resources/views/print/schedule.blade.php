@extends('layouts.my')

@section('content')

 

<center>

<h1>Schedule Information List </h1>

<table class="table" >

<tr><th>Id</th><th>Name</th><th>Tanggal</th></tr>

 

 @foreach($schedules as $schedule)

 <tr><td>{{ $schedule->id }}</td>

     <td>{{ $schedule->name }}</td>

     <td>{{ $schedule->detail }}</td>

 

 </tr>

 @endforeach

 

</center>

@endsection
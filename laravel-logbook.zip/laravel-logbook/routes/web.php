<?php

Route::resource('products','ProductController');

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/schedule','PrintController@index');

Route::get('/prnpriview','PrintController@prnpriview');

Route::match(['get', 'post'], '/gantt_data', "GanttController@data");
<?php $__env->startSection('content'); ?>

 

<center>

<h1>Schedule Information List </h1>

<table class="table" >

<tr><th>Id</th><th>Name</th><th>Email</th></tr>

 

 <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

 <tr><td><?php echo e($schedule->id); ?></td>

     <td><?php echo e($schedule->name); ?></td>

     <td><?php echo e($schedule->detail); ?></td>

 

 </tr>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

 

</center>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.my', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>